﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace Tic_Tac_Toe_2
{

    public partial class Title : Form
    {
        public static Int32 d = 0;
        public static Int32 aa = 0;
        public static Int32 g = 0;
        public static Int32 f = 0;
        public static Int32 h = 0;
        public enum player
        {
            X,O
        }
        player currentplayer;
        List<Button> buttons;
        Random rand = new Random();
        int playerwins = 0;
        int computerwins = 0;
        private void loadbutton()
        {
            buttons = new List<Button> { button1, button2, button3, button4, button5, button6, button7, button8, button9 };
        }

        public Title()
        {
            
            InitializeComponent();
            label1.BackColor = System.Drawing.Color.Green;
            label1.Text ="Press play ";
            label1.BackColor = Color.White;
            button();
            
   
        }
        private void button()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;

          
        }
        private void Reset()
        {
              foreach (Control X in this.Controls)
              { 
                if (X is Button )
                {
                    ((Button) X).Enabled = true;
                    button1.Text = " ";
                    button2.Text = " ";
                    button3.Text = " ";
                    button4.Text = " ";
                    button5.Text = " ";
                    button6.Text = " ";
                    button7.Text = " ";
                    button8.Text = " ";
                    button9.Text = " ";


                }
              }
            Almoves.Stop();
            loadbutton();
            
        }
        private void Result()
        {
          

            if (
           button1.Text == "X" && button5.Text == "X" && button9.Text == "X" ||
           button1.Text == "X" && button4.Text == "X" && button7.Text == "X"
           || button1.Text == "X" && button3.Text == "X" && button2.Text == "X" 
           || button2.Text == "X" && button5.Text == "X" && button8.Text == "X"
           || button3.Text == "X" && button6.Text == "X" && button9.Text == "X" 
           || button3.Text == "X" && button5.Text == "X" && button7.Text == "X"
           || button4.Text == "X" && button5.Text == "X" && button6.Text == "X" 
           || button7.Text == "X" && button8.Text == "X" && button9.Text == "X")
            {


                Almoves.Stop();
                button10.Enabled = true;
                button13.Enabled = true;
                f++;
                d++;
                MessageBox.Show(Form1.a + " wins ", "Tic Tac Toe", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
              
                
                Reset();
                button();
                label1.BackColor = Color.White;
                label1.Text = "Press play to play again";
                if (Form1.c == f)
                {
                    label1.Text = "Series End";
                }


            }
            else if
                (button1.Text == "O" && button5.Text == "O" && button9.Text == "O" ||
                button1.Text == "O" && button4.Text == "O" && button7.Text == "O"
               || button1.Text == "O" && button3.Text == "O" && button2.Text == "O" ||
               button2.Text == "O" && button5.Text == "O" && button8.Text == "O"
                || button3.Text == "O" && button6.Text == "O" && button9.Text == "O" || 
                button3.Text == "O" && button5.Text == "O" && button7.Text == "O"
                 || button4.Text == "O" && button5.Text == "O" && button6.Text == "O" || 
                 button7.Text == "O" && button8.Text == "O" && button9.Text == "O")

                 {
                  Almoves.Stop();
                  button10.Enabled = true;
                  button13.Enabled = true;
                  f++;
                  aa++;
                   MessageBox.Show(Form1.b + " wins ", "Tic Tac Toe", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
               
              
                  Reset();
                  button();
                  label1.BackColor = Color.White;
                  label1.Text = "Press play to play again";
                   if (Form1.c == f)
                   {
                    label1.Text = "Series End";
                   }

                 }
            else if ((button1.Text == "X" || button1.Text == "O") &&
                     (button2.Text == "X" || button2.Text == "O") &&
                    (button3.Text == "X" || button3.Text == "O") &&
                     (button4.Text == "X" || button4.Text == "O") &&
                     (button5.Text == "X" || button5.Text == "O") &&
                     (button6.Text == "X" || button6.Text == "O") &&
                     (button7.Text == "X" || button7.Text == "O") &&
                    (button8.Text == "X" || button8.Text == "O") &&
                     (button9.Text == "X" || button9.Text == "O"))
                 {


                  Almoves.Stop();
              
               
                  button10.Enabled = true;
                  button13.Enabled = true;
                  f++;
                  g++;
                  MessageBox.Show("Game Tied", "Tic Tac Toe", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                  Reset();
                  label1.BackColor = Color.White;
                  label1.Text = "Press play to play again";
                   if (Form1.c == f)
                   {
                    label1.Text = "Series End";
                }

                 }


        }

        int count = 0;
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
                label1.Text = "Computer Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
                
                Almoves.Start();
                Result();
            }
            else
            {
                if (count == 0)

                {
                    
                    button1.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;

                }
                else if (count == 1)
                {
                    button1.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = System.Drawing.Color.Green;
                }
                button1.Enabled = false;
                Result();
            }

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
                label1.Text = "Computer Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
               
                Almoves.Start();
                Result();
            }
            else
            {

                if (count == 0)

                {
                    button2.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;
                }
                else if (count == 1)
                {
                    button2.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = System.Drawing.Color.Green;
                }
                button2.Enabled = false;
                Result();
            }
                

        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
                label1.Text = "Computer Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
               
                Almoves.Start();
                Result();
            }
            else
            {
                if (count == 0)

                {
                    button3.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;
                }
                else if (count == 1)
                {
                    button3.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = System.Drawing.Color.Green;
                }
                button3.Enabled = false;
                Result();
            }

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
                label1.Text = "Computer Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
               
                Almoves.Start();
                Result();
            }
            else
            {
                if (count == 0)

                {
                    button4.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;
                }
                else if (count == 1)
                {
                    button4.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = System.Drawing.Color.Green;
                }
                button4.Enabled = false;
                Result();
            }

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
                label1.Text = "Computer Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
                
                Almoves.Start();
                Result();
            }
            else
            {
                if (count == 0)

                {
                    button5.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;
                }
                else if (count == 1)
                {
                    button5.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = System.Drawing.Color.Green;
                }
                button5.Enabled = false;
                Result();
            }

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
                label1.Text = "Computer Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
               
                Almoves.Start();
                Result();
            }
            else
            {
                if (count == 0)

                {
                    button6.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;
                }
                else if (count == 1)
                {
                    button6.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = System.Drawing.Color.Green;
                }
                button6.Enabled = false;
                Result();
            }
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
                label1.Text = Form1.a + " Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
               
                Almoves.Start();
                Result();
            }
            else
            {

                if (count == 0)

                {
                    button7.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;
                }
                else if (count == 1)
                {
                    button7.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = System.Drawing.Color.Green;
                }
                button7.Enabled = false;
                Result();
            }
        }
        private void button8_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
                label1.Text = "Computer Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
              
                Almoves.Start();
                Result();
            }
            else
            {
                if (count == 0)

                {
                    button8.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;
                }
                else if (count == 1)
                {
                    button8.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = System.Drawing.Color.Green;
                }
                button8.Enabled = false;
                Result();
            }

        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            if (Form1.gg == 1)
            {
               
                label1.Text =  "Computer Turn";
                var button = (Button)sender;
                currentplayer = player.X;
                button.Text = currentplayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
               
                Almoves.Start();
                Result();
            }
            else
            {
                if (count == 0)

                {
                    button9.Text = "X";
                    count++;
                    label1.Text = Form1.b + " Turn";
                    label1.BackColor = System.Drawing.Color.Red;
                }
                else if (count == 1)
                {
                    button9.Text = "O";
                    count--;
                    label1.Text = Form1.a + " Turn";
                    label1.BackColor = Color.Green;
                }
                button9.Enabled = false;
                Result();
            }

        }


        private void button11_Click_1(object sender, EventArgs e)
        {
            button10.Enabled = false;
            button13.Enabled = false;
            Form1 title = new Form1();


            if (Form1.q == 1)
            {
               
                button10.Enabled = false;

                if (Form1.c > f)
                {
                    button1.Text = " ";
                    button2.Text = " ";
                    button3.Text = " ";
                    button4.Text = " ";
                    button5.Text = " ";
                    button6.Text = " ";
                    button7.Text = " ";
                    button8.Text = " ";
                    button9.Text = " ";

                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = true;
                    button4.Enabled = true;
                    button5.Enabled = true;
                    button6.Enabled = true;
                    button7.Enabled = true;
                    button8.Enabled = true;
                    button9.Enabled = true;
                    count = 0;
                    label1.BackColor = Color.Green;
                    label1.Text = Form1.a + " Turn";
                    loadbutton();

                }

                else

                {
                    MessageBox.Show("Series end, Start a new game","Tic Tac Toe",MessageBoxButtons.AbortRetryIgnore,MessageBoxIcon.Error);
                    button10.Enabled = true;
                    button13.Enabled = true;
                    label1.Text = "Game Over";

                    
                }
            }
            else
            {
                button1.Text = " ";
                button2.Text = " ";
                button3.Text = " ";
                button4.Text = " ";
                button5.Text = " ";
                button6.Text = " ";
                button7.Text = " ";
                button8.Text = " ";
                button9.Text = " ";

                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                button6.Enabled = true;
                button7.Enabled = true;
                button8.Enabled = true;
                button9.Enabled = true;
                count = 0;
                label1.BackColor = Color.Green;
                label1.Text = Form1.a + " Turn";
                loadbutton();
                Almoves.Stop();
               
            }

        }

            private void button12_Click_1(object sender, EventArgs e)
            {
            Form3 frm = new Form3();
            frm.ShowDialog();
            }

            private void Title_Load(object sender, EventArgs e)
            {

            }

            private void rulesToolStripMenuItem_Click(object sender, EventArgs e)
            {
                MessageBox.Show("The object of Tic Tac Toe is to get three in a row. " + " You play on a three by three game board. " +
                    "The first player is known as X and the second is O. " +
                    "Players alternate placing Xs and Os on the game board until either oppent has three in a row or all nine squares are filled.", "Tic Tac Toe", MessageBoxButtons.OKCancel
                    , MessageBoxIcon.Information);
            }

            private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
            {
                MessageBox.Show("All right reserved with \n Saiyid Sarmed Hasan Rizvi ",

                    "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            private void endToolStripMenuItem_Click(object sender, EventArgs e)
            {
                Application.Exit();
            }

            private void label1_Click(object sender, EventArgs e)
            {

            }

          private void button10_Click(object sender, EventArgs e)
          {
              if (Form1.q == 1)
              {
                label1.Text = " ";
                label1.BackColor = Color.White;

                if (Form1.c == f)

                {
                    Form2 frm = new Form2();
                    frm.Show();
                    button();
                    label1.Text = " ";
                    label1.BackColor = Color.White;
                  
                }
                else
                {

                    MessageBox.Show("Complete the series ",

                    "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    label1.Text = "Press Play";

                }
              }
              else
              {
                Form2 frm = new Form2();
                frm.Show();
                button();
                label1.Text = " ";
                label1.BackColor = Color.White;
                
              }
          }

            private void button13_Click(object sender, EventArgs e)
            {

                MessageBox.Show(Form1.a + " Score is " + d + "\n\nGame tied " + g + " Times\n\n" + Form1.b + " Score is " + aa,"Score Board",MessageBoxButtons.OK,MessageBoxIcon.Information);


            }

        private void Almove(object sender, EventArgs e)
        {
            if (buttons.Count>0)
            {
                label1.Text = Form1.a + " Turn";
                int index = rand.Next(buttons.Count);
                buttons[index].Enabled = false;
                currentplayer = player.O;
                buttons[index].Text = currentplayer.ToString();
                buttons.RemoveAt(index);
                Result();
                Almoves.Stop();
               
            }

        }

        private void Title_KeyUp(object sender, KeyEventArgs e)
        {

        }
    }
}

  
