﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe_2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Write player Names", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                }
                else
                {
                    if (checkBox1.Checked)
                    {
                        
                        if (string.IsNullOrWhiteSpace(textBox3.Text))
                        {
                            MessageBox.Show("Write Number of games to be played", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        }
                        else if (int.TryParse(textBox3.Text, out Form1.c) == false)
                        {
                            MessageBox.Show("Number of games played should be written in number!!!", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        }
                        else
                        {


                            Form1.a = textBox1.Text;
                            Form1.b = textBox2.Text;
                            MessageBox.Show(Form1.a + " is Player 1 \n" + Form1.b + " is Player 2", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            label1.Text = "Players Changed";
                            this.Hide();
                            Title.d = 0;
                            Title.aa = 0;
                            Title.g = 0;
                            Title.f = 0;
                            Form1.q = 1;
                            Form1.gg = 1;
                            Form1.q=1;
                        }
                    }
                    else if (checkBox2.Checked)
                    {

                        Form1.a = textBox1.Text;
                        Form1.b = textBox2.Text;
                        MessageBox.Show(Form1.a + " is Player 1 \n" + Form1.b + " is Player 2", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                      
                        this.Hide();
                        Title.d = 0;
                        Title.aa = 0;
                        Title.g = 0;
                        Title.f = 0;
                        Form1.q = 0;
                        Form1.c = 0;
                        Form1.gg = 1;
                        

                    }
                    else
                    {
                        MessageBox.Show("Please check the boxes", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    }
                }
            }
            else if(checkBox4.Checked)
            {
               
                if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Write player Names", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                }
                else
                {
                    if (checkBox1.Checked)
                    {
                     
                        if (string.IsNullOrWhiteSpace(textBox3.Text))
                        {
                            MessageBox.Show("Write Number of games to be played", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        }
                        else if (int.TryParse(textBox3.Text, out Form1.c) == false)
                        {
                            MessageBox.Show("Number of games played should be written in number!!!", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        }
                        else
                        {


                            Form1.a = textBox1.Text;
                            Form1.b = textBox2.Text;
                            MessageBox.Show(Form1.a + " is Player 1 \n" + Form1.b + " is Player 2", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                           
                            this.Hide();
                            Title.d = 0;
                            Title.aa = 0;
                            Title.g = 0;
                            Title.f = 0;
                            Form1.q = 1;
                            Form1.gg = 0;


                        }
                    }
                    else if (checkBox2.Checked)
                    {

                        Form1.a = textBox1.Text;
                        Form1.b = textBox2.Text;
                        MessageBox.Show(Form1.a + " is Player 1 \n" + Form1.b + " is Player 2", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        label1.Text = "Players Changed";
                        label1.BackColor = Color.Black;
                        this.Hide();
                        Title.d = 0;
                        Title.aa = 0;
                        Title.g = 0;
                        Title.f = 0;
                        Form1.q = 0;
                        Form1.c = 0;
                        Form1.gg = 0;



                    }
                    else
                    {
                        MessageBox.Show("Please check the boxes", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    }
                }
            }


        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            checkBox1.Checked = false;
            textBox3.Enabled = false;
           
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            checkBox2.Checked = false;
            textBox3.Enabled = true;


        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox2.Text = "Computer";
            checkBox4.Checked = false;
            textBox2.Enabled = false;
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox2.Text = " ";
            textBox2.Enabled = true;
            checkBox3.Checked = false;
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
