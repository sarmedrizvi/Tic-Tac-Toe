﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Tic_Tac_Toe_2
{
    public partial class Form1 : Form
    {
        Thread th;
       
       


        public Form1()
        {
            InitializeComponent();

            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
          
          
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        public static string a = "";
        public static string b = "";
        public static Int32 c = 0;
        public static Int32 q = 0;
        public static Int32 gg = 0;



        private void button1_Click(object sender, EventArgs e)
        {
            Title title = new Title();
            a = textBox1.Text;
            b = textBox2.Text;
            if (checkBox4.Checked)
            {
               
                checkBox3.Checked = false;
                textBox2.Enabled = false;
               
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Write player Names", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);

                }
                else
                {


                    if (checkBox1.Checked)
                    {
                      
                        if (string.IsNullOrWhiteSpace(textBox3.Text))
                        {
                            MessageBox.Show("Write Number of games to be played", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        }
                        else if (int.TryParse(textBox3.Text, out c) == false)
                        {
                            MessageBox.Show("Number of games played should be written in number!!!", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show(a + " is Player 1 \n" + " Computer is Player 2", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            th = new Thread(opennewform);
                            th.SetApartmentState(ApartmentState.STA);
                            th.Start();
                            this.Close();
                            textBox2.Enabled = false;
                            gg = 1;
                            q++;

                        }
                    }
                    else if (checkBox2.Checked)
                    {
                        MessageBox.Show(a + " is Player 1 \n" + " Computer is Player 2", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        th = new Thread(opennewform);
                        th.SetApartmentState(ApartmentState.STA);
                        th.Start();
                        this.Close();
                        textBox2.Enabled = false;
                        gg = 1;



                    }
                    else
                    {
                        MessageBox.Show("Please check the boxes", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    }
                }

               

            }
            else if(checkBox3.Checked)
            {
                checkBox4.Checked = false;
                textBox2.Enabled = true;

                if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Write player Names", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);

                }
                else
                {


                    if (checkBox1.Checked)
                    {
                       
                        if (string.IsNullOrWhiteSpace(textBox3.Text))
                        {
                            MessageBox.Show("Write Number of games to be played", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        }
                        else if (int.TryParse(textBox3.Text, out c) == false)
                        {
                            MessageBox.Show("Number of games played should be written in number!!!", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        }
                        else
                        {

                            c = Convert.ToInt32(textBox3.Text);
                            MessageBox.Show(a + " is Player 1 \n" + b + " is Player 2", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            th = new Thread(opennewform);
                            th.SetApartmentState(ApartmentState.STA);
                            th.Start();
                            this.Close(); q++;

                        }
                    }
                    else if (checkBox2.Checked)
                    {
                        MessageBox.Show(a + " is Player 1 \n" + b + " is Player 2", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        th = new Thread(opennewform);
                        th.SetApartmentState(ApartmentState.STA);
                        th.Start();
                        this.Close();


                    }
                    else
                    {
                        MessageBox.Show("Please check the boxes", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please check the boxes", "Tic Tac Toe", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }
        private void opennewform()
        {
            Application.Run(new Title());

        }


        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

      

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            checkBox2.Checked = false;
            textBox3.Enabled = true;
          

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
                checkBox1.Checked = false;
            textBox3.Enabled = false;
       
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
            textBox2.Text = "Computer";
            checkBox3.Checked = false;
            textBox2.Enabled = false;
            textBox1.Enabled = true;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Text = "";
            checkBox4.Checked = false;
            textBox2.Enabled = true;
            textBox1.Enabled = true;
          
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
        }

        private void endToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The object of Tic Tac Toe is to get three in a row. " + " You play on a three by three game board. " +
                  "The first player is known as X and the second is O. " +
                  "Players alternate placing Xs and Os on the game board until either oppent has three in a row or all nine squares are filled.", "Tic Tac Toe", MessageBoxButtons.OKCancel
                  , MessageBoxIcon.Information);
        }

        private void checkBox4_CheckStateChanged(object sender, EventArgs e)
        {
          

        }
    }
}
